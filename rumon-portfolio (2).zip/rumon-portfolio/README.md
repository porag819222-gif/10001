# Rumon — Portfolio

A one-page "player profile" portfolio site built with React + Vite.

- **Name:** Rumon
- **Class:** 10
- **Blood Group:** B+
- **Hobby:** Gaming
- **School:** MMA

## Run locally

```bash
npm install
npm run dev
```

Then open the printed local URL (usually `http://localhost:5173`).

## Build

```bash
npm run build
```

This outputs a production-ready static site into the `dist/` folder.

## Deploy to Cloudflare Pages

### Option A — Connect a Git repo (recommended)
1. Push this project to a GitHub/GitLab repo.
2. In the Cloudflare dashboard, go to **Workers & Pages → Create → Pages → Connect to Git**.
3. Select the repo and use these build settings:
   - **Framework preset:** Vite
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
4. Click **Save and Deploy**.

### Option B — Direct upload (no Git needed)
1. Run `npm install && npm run build` locally to generate the `dist/` folder.
2. In the Cloudflare dashboard, go to **Workers & Pages → Create → Pages → Upload assets**.
3. Drag and drop the `dist/` folder.
4. Click **Deploy site**.

### Option C — Wrangler CLI
```bash
npm install -g wrangler
npm run build
wrangler pages deploy dist --project-name=rumon-portfolio
```

A `_redirects` file is already included in `public/` for correct routing on Cloudflare Pages.

## Customize

- **Photo:** replace `src/assets/rumon.jpg` with a new image (keep the same filename, or update the import in `src/App.jsx`).
- **Text/content:** edit `src/App.jsx` — the `STATS` and `LOADOUT` arrays plus the JSX in each section.
- **Colors/fonts:** edit the CSS variables at the top of `src/index.css` (`:root { ... }`).
- **Contact form:** the form currently just shows an alert on submit. Wire it up to a real service (e.g. [Formspree](https://formspree.io)) by setting the `action` attribute on the `<form>` in `src/App.jsx`, or connect it to your own backend/email API.

## Tech stack

- React 18
- Vite 5
- Plain CSS (no framework) — custom "gamer HUD" design system defined via CSS variables
