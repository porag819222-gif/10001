import { useEffect, useState } from 'react'
import rumonPhoto from './assets/rumon.jpg'

const STATS = [
  { label: 'NAME', value: 'Rumon', mono: false },
  { label: 'CLASS', value: '10', mono: false },
  { label: 'BLOOD GROUP', value: 'B+', mono: false },
  { label: 'SCHOOL', value: 'MMA', mono: false },
  { label: 'MAIN HOBBY', value: 'Gaming', mono: false },
]

const LOADOUT = [
  {
    tag: 'HOBBY',
    title: 'Gaming',
    desc: 'Spends free time deep in games — chasing high scores, learning maps, and grinding ranked matches. Strategy and reflexes over luck.',
  },
  {
    tag: 'SCHOOL',
    title: 'MMA — Class 10',
    desc: 'Currently a Class 10 student at MMA, balancing schoolwork with games and everyday grind.',
  },
  {
    tag: 'STAT',
    title: 'Blood Group B+',
    desc: 'Good to know in an emergency — carried on the profile for anyone who needs it.',
  },
]

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal')
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('is-visible')
            obs.unobserve(e.target)
          }
        })
      },
      { threshold: 0.15 }
    )
    els.forEach((el) => obs.observe(el))
    return () => obs.disconnect()
  }, [])
}

function Bracket({ className = '' }) {
  return (
    <svg className={`bracket ${className}`} width="28" height="28" viewBox="0 0 28 28" fill="none">
      <path d="M2 12V4a2 2 0 0 1 2-2h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function CornerFrame() {
  return (
    <>
      <Bracket className="corner tl" />
      <Bracket className="corner tr" />
      <Bracket className="corner bl" />
      <Bracket className="corner br" />
    </>
  )
}

export default function App() {
  const [navOpen, setNavOpen] = useState(false)
  useReveal()

  const links = [
    { href: '#profile', label: 'Profile' },
    { href: '#about', label: 'About' },
    { href: '#loadout', label: 'Loadout' },
    { href: '#contact', label: 'Contact' },
  ]

  return (
    <>
      <div className="scanline" aria-hidden="true" />

      <header className="nav">
        <a href="#top" className="nav__logo">
          RUMON<span className="nav__dot">_</span>
        </a>
        <nav className={`nav__links ${navOpen ? 'is-open' : ''}`}>
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setNavOpen(false)}>
              {l.label}
            </a>
          ))}
        </nav>
        <button
          className="nav__toggle"
          aria-label="Toggle menu"
          onClick={() => setNavOpen((v) => !v)}
        >
          <span />
          <span />
          <span />
        </button>
      </header>

      <main id="top">
        {/* PLAYER CARD / HERO */}
        <section id="profile" className="hero">
          <div className="hero__grid">
            <div className="hero__portrait reveal">
              <div className="portrait-frame">
                <CornerFrame />
                <img src={rumonPhoto} alt="Rumon standing by the river" />
                <div className="portrait-tag">
                  <span className="dot" /> ONLINE
                </div>
              </div>
            </div>

            <div className="hero__card reveal">
              <p className="eyebrow">// PLAYER PROFILE</p>
              <h1 className="hero__name">
                RUMON
                <span className="hero__level">LVL 10</span>
              </h1>
              <p className="hero__tagline">
                Class 10 student at MMA. Full-time gamer, part-time student —
                or maybe it's the other way around.
              </p>

              <dl className="stat-list">
                {STATS.map((s) => (
                  <div className="stat-row" key={s.label}>
                    <dt>{s.label}</dt>
                    <dd>{s.value}</dd>
                  </div>
                ))}
              </dl>

              <div className="bar-group">
                <div className="bar">
                  <div className="bar__label">
                    <span>GAME ENERGY</span>
                    <span>92%</span>
                  </div>
                  <div className="bar__track">
                    <div className="bar__fill bar__fill--teal" style={{ width: '92%' }} />
                  </div>
                </div>
                <div className="bar">
                  <div className="bar__label">
                    <span>FOCUS</span>
                    <span>78%</span>
                  </div>
                  <div className="bar__track">
                    <div className="bar__fill bar__fill--amber" style={{ width: '78%' }} />
                  </div>
                </div>
              </div>

              <div className="hero__cta">
                <a href="#contact" className="btn btn--primary">
                  Get In Touch
                </a>
                <a href="#loadout" className="btn btn--ghost">
                  View Loadout
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="section about">
          <div className="section__head reveal">
            <p className="eyebrow">// ABOUT</p>
            <h2>Who's Rumon?</h2>
          </div>
          <div className="about__body reveal">
            <p>
              Rumon is a Class 10 student at MMA who spends most of his free
              hours in front of a screen, grinding games and figuring out
              what makes a strategy actually work. School during the day,
              respawns in the evening — that's the routine.
            </p>
            <p>
              This page is his player card: a quick, honest look at who he
              is, what he's into, and how to reach him. Blood group listed
              for the just-in-case moments — always good to have it on hand.
            </p>
          </div>
        </section>

        {/* LOADOUT */}
        <section id="loadout" className="section loadout">
          <div className="section__head reveal">
            <p className="eyebrow">// LOADOUT</p>
            <h2>What he's equipped with</h2>
          </div>
          <div className="loadout__grid">
            {LOADOUT.map((item, i) => (
              <div className="loadout-card reveal" key={item.title} style={{ transitionDelay: `${i * 80}ms` }}>
                <CornerFrame />
                <span className="loadout-card__tag">{item.tag}</span>
                <h3>{item.title}</h3>
                <p>{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="section contact">
          <div className="contact__panel reveal">
            <CornerFrame />
            <p className="eyebrow">// CONTACT</p>
            <h2>Send a message</h2>
            <p className="contact__sub">
              Drop a note below — replace this form's action with your own
              email service or Formspree endpoint before deploying.
            </p>
            <form
              className="contact__form"
              onSubmit={(e) => {
                e.preventDefault()
                alert('Thanks for the message! (Hook this form up to an email service like Formspree to make it live.)')
                e.target.reset()
              }}
            >
              <div className="field">
                <label htmlFor="name">Name</label>
                <input id="name" name="name" type="text" placeholder="Your name" required />
              </div>
              <div className="field">
                <label htmlFor="email">Email</label>
                <input id="email" name="email" type="email" placeholder="you@example.com" required />
              </div>
              <div className="field">
                <label htmlFor="message">Message</label>
                <textarea id="message" name="message" rows="4" placeholder="Say hi..." required />
              </div>
              <button type="submit" className="btn btn--primary">
                Send Message
              </button>
            </form>
          </div>
        </section>
      </main>

      <footer className="footer">
        <p>
          © {new Date().getFullYear()} Rumon — Class 10, MMA. Built with React
          + Vite.
        </p>
      </footer>
    </>
  )
}
